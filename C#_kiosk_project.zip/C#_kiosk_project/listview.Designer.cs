﻿namespace pj01
{
    partial class listview
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            listView1 = new System.Windows.Forms.ListView();
            menu = new System.Windows.Forms.ColumnHeader();
            num = new System.Windows.Forms.ColumnHeader();
            price = new System.Windows.Forms.ColumnHeader();
            tbName = new System.Windows.Forms.TextBox();
            tbPhone = new System.Windows.Forms.TextBox();
            tbOrg = new System.Windows.Forms.TextBox();
            button1 = new System.Windows.Forms.Button();
            button2 = new System.Windows.Forms.Button();
            button3 = new System.Windows.Forms.Button();
            SuspendLayout();
            // 
            // listView1
            // 
            listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] { menu, num, price });
            listView1.Location = new System.Drawing.Point(114, 233);
            listView1.Name = "listView1";
            listView1.Size = new System.Drawing.Size(325, 149);
            listView1.TabIndex = 0;
            listView1.UseCompatibleStateImageBehavior = false;
            // 
            // menu
            // 
            menu.Text = "일번";
            // 
            // num
            // 
            num.Text = "갯수";
            // 
            // price
            // 
            price.Text = "가격";
            // 
            // tbName
            // 
            tbName.Location = new System.Drawing.Point(191, 104);
            tbName.Name = "tbName";
            tbName.Size = new System.Drawing.Size(100, 23);
            tbName.TabIndex = 1;
            // 
            // tbPhone
            // 
            tbPhone.Location = new System.Drawing.Point(191, 133);
            tbPhone.Name = "tbPhone";
            tbPhone.Size = new System.Drawing.Size(100, 23);
            tbPhone.TabIndex = 2;
            // 
            // tbOrg
            // 
            tbOrg.Location = new System.Drawing.Point(191, 162);
            tbOrg.Name = "tbOrg";
            tbOrg.Size = new System.Drawing.Size(100, 23);
            tbOrg.TabIndex = 3;
            // 
            // button1
            // 
            button1.Location = new System.Drawing.Point(297, 104);
            button1.Name = "button1";
            button1.Size = new System.Drawing.Size(75, 23);
            button1.TabIndex = 4;
            button1.Text = "입력";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new System.Drawing.Point(297, 133);
            button2.Name = "button2";
            button2.Size = new System.Drawing.Size(75, 23);
            button2.TabIndex = 5;
            button2.Text = "삭제";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Location = new System.Drawing.Point(297, 163);
            button3.Name = "button3";
            button3.Size = new System.Drawing.Size(75, 23);
            button3.TabIndex = 6;
            button3.Text = "수정";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // listview
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(800, 450);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(tbOrg);
            Controls.Add(tbPhone);
            Controls.Add(tbName);
            Controls.Add(listView1);
            Name = "listview";
            Text = "listview";
            Load += listview_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader menu;
        private System.Windows.Forms.ColumnHeader num;
        private System.Windows.Forms.ColumnHeader price;
        private System.Windows.Forms.TextBox tbName;
        private System.Windows.Forms.TextBox tbPhone;
        private System.Windows.Forms.TextBox tbOrg;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
    }
}