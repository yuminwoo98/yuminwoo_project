﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pj01
{
    public partial class listview : Form
    {
        public listview()
        {
            InitializeComponent();
            listView1.View = View.Details;
        }

        private void listview_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (tbName.Text == "" || tbName.Text == "" || tbOrg.Text == "")
                MessageBox.Show("제대로 입력해");
            else
                listView1.Items.Add(new ListViewItem(new string[] { tbName.Text, tbPhone.Text, tbOrg.Text }));
        }

        private void button2_Click(object sender, EventArgs e) // 이름을 눌러서 선택해서 삭제 가능
        {
            try
            {
                int index = listView1.FocusedItem.Index;
                listView1.Items.RemoveAt(index);
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (tbName.Text == "" || tbPhone.Text == "" || tbOrg.Text == "")
                MessageBox.Show("오 ㅋ");
            try
            {
                listView1.SelectedItems[0].SubItems[0].Text = tbName.Text;
            }
            catch { MessageBox.Show("오류"); }
        }
    }
}
