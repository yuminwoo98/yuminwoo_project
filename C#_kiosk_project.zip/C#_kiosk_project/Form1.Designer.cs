﻿namespace pj01
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            splitContainer1 = new System.Windows.Forms.SplitContainer();
            button2 = new System.Windows.Forms.Button();
            button1 = new System.Windows.Forms.Button();
            pictureBox1 = new System.Windows.Forms.PictureBox();
            splitContainer2 = new System.Windows.Forms.SplitContainer();
            button6 = new System.Windows.Forms.Button();
            button5 = new System.Windows.Forms.Button();
            tabControl1 = new System.Windows.Forms.TabControl();
            tabPage1 = new System.Windows.Forms.TabPage();
            button34 = new System.Windows.Forms.Button();
            button35 = new System.Windows.Forms.Button();
            button36 = new System.Windows.Forms.Button();
            button37 = new System.Windows.Forms.Button();
            button30 = new System.Windows.Forms.Button();
            button31 = new System.Windows.Forms.Button();
            button32 = new System.Windows.Forms.Button();
            button33 = new System.Windows.Forms.Button();
            button26 = new System.Windows.Forms.Button();
            button27 = new System.Windows.Forms.Button();
            button28 = new System.Windows.Forms.Button();
            button29 = new System.Windows.Forms.Button();
            button22 = new System.Windows.Forms.Button();
            button23 = new System.Windows.Forms.Button();
            button24 = new System.Windows.Forms.Button();
            button25 = new System.Windows.Forms.Button();
            button18 = new System.Windows.Forms.Button();
            button19 = new System.Windows.Forms.Button();
            button20 = new System.Windows.Forms.Button();
            button21 = new System.Windows.Forms.Button();
            button14 = new System.Windows.Forms.Button();
            button15 = new System.Windows.Forms.Button();
            button16 = new System.Windows.Forms.Button();
            button17 = new System.Windows.Forms.Button();
            button13 = new System.Windows.Forms.Button();
            button12 = new System.Windows.Forms.Button();
            button11 = new System.Windows.Forms.Button();
            button10 = new System.Windows.Forms.Button();
            button9 = new System.Windows.Forms.Button();
            button8 = new System.Windows.Forms.Button();
            label2 = new System.Windows.Forms.Label();
            label1 = new System.Windows.Forms.Label();
            btn_test2 = new System.Windows.Forms.Button();
            btn_test = new System.Windows.Forms.Button();
            tabPage2 = new System.Windows.Forms.TabPage();
            button7 = new System.Windows.Forms.Button();
            button39 = new System.Windows.Forms.Button();
            button40 = new System.Windows.Forms.Button();
            button41 = new System.Windows.Forms.Button();
            button42 = new System.Windows.Forms.Button();
            button43 = new System.Windows.Forms.Button();
            button44 = new System.Windows.Forms.Button();
            button45 = new System.Windows.Forms.Button();
            button46 = new System.Windows.Forms.Button();
            button47 = new System.Windows.Forms.Button();
            button48 = new System.Windows.Forms.Button();
            button49 = new System.Windows.Forms.Button();
            tabPage3 = new System.Windows.Forms.TabPage();
            button50 = new System.Windows.Forms.Button();
            button51 = new System.Windows.Forms.Button();
            button52 = new System.Windows.Forms.Button();
            button53 = new System.Windows.Forms.Button();
            button54 = new System.Windows.Forms.Button();
            button55 = new System.Windows.Forms.Button();
            button56 = new System.Windows.Forms.Button();
            button57 = new System.Windows.Forms.Button();
            button58 = new System.Windows.Forms.Button();
            button59 = new System.Windows.Forms.Button();
            button60 = new System.Windows.Forms.Button();
            button61 = new System.Windows.Forms.Button();
            tabPage4 = new System.Windows.Forms.TabPage();
            button62 = new System.Windows.Forms.Button();
            button63 = new System.Windows.Forms.Button();
            button64 = new System.Windows.Forms.Button();
            button65 = new System.Windows.Forms.Button();
            button66 = new System.Windows.Forms.Button();
            button67 = new System.Windows.Forms.Button();
            button68 = new System.Windows.Forms.Button();
            button69 = new System.Windows.Forms.Button();
            button70 = new System.Windows.Forms.Button();
            button71 = new System.Windows.Forms.Button();
            button72 = new System.Windows.Forms.Button();
            button73 = new System.Windows.Forms.Button();
            tabPage5 = new System.Windows.Forms.TabPage();
            button74 = new System.Windows.Forms.Button();
            button75 = new System.Windows.Forms.Button();
            button76 = new System.Windows.Forms.Button();
            button77 = new System.Windows.Forms.Button();
            button78 = new System.Windows.Forms.Button();
            button79 = new System.Windows.Forms.Button();
            button80 = new System.Windows.Forms.Button();
            button81 = new System.Windows.Forms.Button();
            button82 = new System.Windows.Forms.Button();
            button83 = new System.Windows.Forms.Button();
            button84 = new System.Windows.Forms.Button();
            button85 = new System.Windows.Forms.Button();
            button4 = new System.Windows.Forms.Button();
            tabPage6 = new System.Windows.Forms.TabPage();
            button86 = new System.Windows.Forms.Button();
            button87 = new System.Windows.Forms.Button();
            button88 = new System.Windows.Forms.Button();
            button89 = new System.Windows.Forms.Button();
            button90 = new System.Windows.Forms.Button();
            button91 = new System.Windows.Forms.Button();
            button92 = new System.Windows.Forms.Button();
            button93 = new System.Windows.Forms.Button();
            button94 = new System.Windows.Forms.Button();
            button95 = new System.Windows.Forms.Button();
            button96 = new System.Windows.Forms.Button();
            button97 = new System.Windows.Forms.Button();
            pictureBox2 = new System.Windows.Forms.PictureBox();
            button38 = new System.Windows.Forms.Button();
            textBox3 = new System.Windows.Forms.TextBox();
            label4 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            textBox2 = new System.Windows.Forms.TextBox();
            btn_pay = new System.Windows.Forms.Button();
            btn_cash = new System.Windows.Forms.Button();
            listView1 = new System.Windows.Forms.ListView();
            menu = new System.Windows.Forms.ColumnHeader();
            num = new System.Windows.Forms.ColumnHeader();
            price = new System.Windows.Forms.ColumnHeader();
            textBox1 = new System.Windows.Forms.TextBox();
            button3 = new System.Windows.Forms.Button();
            contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(components);
            ((System.ComponentModel.ISupportInitialize)splitContainer1).BeginInit();
            splitContainer1.Panel1.SuspendLayout();
            splitContainer1.Panel2.SuspendLayout();
            splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)splitContainer2).BeginInit();
            splitContainer2.Panel1.SuspendLayout();
            splitContainer2.Panel2.SuspendLayout();
            splitContainer2.SuspendLayout();
            tabControl1.SuspendLayout();
            tabPage1.SuspendLayout();
            tabPage2.SuspendLayout();
            tabPage3.SuspendLayout();
            tabPage4.SuspendLayout();
            tabPage5.SuspendLayout();
            tabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // splitContainer1
            // 
            splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            splitContainer1.Location = new System.Drawing.Point(0, 0);
            splitContainer1.Name = "splitContainer1";
            splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            splitContainer1.Panel1.BackColor = System.Drawing.Color.White;
            splitContainer1.Panel1.Controls.Add(button2);
            splitContainer1.Panel1.Controls.Add(button1);
            splitContainer1.Panel1.Controls.Add(pictureBox1);
            splitContainer1.Panel1.ImeMode = System.Windows.Forms.ImeMode.On;
            splitContainer1.Panel1.Paint += splitContainer1_Panel1_Paint;
            // 
            // splitContainer1.Panel2
            // 
            splitContainer1.Panel2.Controls.Add(splitContainer2);
            splitContainer1.Size = new System.Drawing.Size(524, 698);
            splitContainer1.SplitterDistance = 70;
            splitContainer1.TabIndex = 0;
            splitContainer1.SplitterMoved += splitContainer1_SplitterMoved;
            // 
            // button2
            // 
            button2.BackColor = System.Drawing.Color.White;
            button2.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button2.ForeColor = System.Drawing.SystemColors.Highlight;
            button2.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
            button2.Location = new System.Drawing.Point(439, 42);
            button2.Name = "button2";
            button2.Size = new System.Drawing.Size(28, 25);
            button2.TabIndex = 2;
            button2.Text = "H";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.BackColor = System.Drawing.Color.White;
            button1.FlatAppearance.BorderColor = System.Drawing.Color.White;
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            button1.Font = new System.Drawing.Font("맑은 고딕", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button1.ForeColor = System.Drawing.Color.Blue;
            button1.Location = new System.Drawing.Point(49, 41);
            button1.Name = "button1";
            button1.Size = new System.Drawing.Size(59, 26);
            button1.TabIndex = 1;
            button1.Text = "Language";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = System.Drawing.Color.IndianRed;
            pictureBox1.Image = Properties.Resources.s캡처;
            pictureBox1.Location = new System.Drawing.Point(158, 8);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new System.Drawing.Size(193, 59);
            pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // splitContainer2
            // 
            splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            splitContainer2.Location = new System.Drawing.Point(0, 0);
            splitContainer2.Name = "splitContainer2";
            splitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer2.Panel1
            // 
            splitContainer2.Panel1.AutoScroll = true;
            splitContainer2.Panel1.BackColor = System.Drawing.Color.RoyalBlue;
            splitContainer2.Panel1.Controls.Add(button6);
            splitContainer2.Panel1.Controls.Add(button5);
            splitContainer2.Panel1.Controls.Add(tabControl1);
            splitContainer2.Panel1.Paint += splitContainer2_Panel1_Paint;
            // 
            // splitContainer2.Panel2
            // 
            splitContainer2.Panel2.BackColor = System.Drawing.Color.DarkGray;
            splitContainer2.Panel2.Controls.Add(pictureBox2);
            splitContainer2.Panel2.Controls.Add(button38);
            splitContainer2.Panel2.Controls.Add(textBox3);
            splitContainer2.Panel2.Controls.Add(label4);
            splitContainer2.Panel2.Controls.Add(label3);
            splitContainer2.Panel2.Controls.Add(textBox2);
            splitContainer2.Panel2.Controls.Add(btn_pay);
            splitContainer2.Panel2.Controls.Add(btn_cash);
            splitContainer2.Panel2.Controls.Add(listView1);
            splitContainer2.Panel2.Controls.Add(textBox1);
            splitContainer2.Panel2.Controls.Add(button3);
            splitContainer2.Panel2.Paint += splitContainer2_Panel2_Paint;
            splitContainer2.Size = new System.Drawing.Size(524, 624);
            splitContainer2.SplitterDistance = 382;
            splitContainer2.TabIndex = 0;
            // 
            // button6
            // 
            button6.FlatAppearance.BorderSize = 0;
            button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            button6.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button6.ForeColor = System.Drawing.SystemColors.ButtonFace;
            button6.Location = new System.Drawing.Point(468, 3);
            button6.Name = "button6";
            button6.Size = new System.Drawing.Size(44, 35);
            button6.TabIndex = 2;
            button6.Text = "▶";
            button6.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            button5.BackColor = System.Drawing.Color.RoyalBlue;
            button5.FlatAppearance.BorderColor = System.Drawing.Color.RoyalBlue;
            button5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.RoyalBlue;
            button5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.RoyalBlue;
            button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            button5.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button5.ForeColor = System.Drawing.SystemColors.ButtonFace;
            button5.Location = new System.Drawing.Point(3, 3);
            button5.Name = "button5";
            button5.Size = new System.Drawing.Size(44, 35);
            button5.TabIndex = 1;
            button5.Text = "◀";
            button5.UseVisualStyleBackColor = false;
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Controls.Add(tabPage3);
            tabControl1.Controls.Add(tabPage4);
            tabControl1.Controls.Add(tabPage5);
            tabControl1.Controls.Add(tabPage6);
            tabControl1.ItemSize = new System.Drawing.Size(69, 30);
            tabControl1.Location = new System.Drawing.Point(49, 3);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new System.Drawing.Size(418, 377);
            tabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            tabPage1.AutoScroll = true;
            tabPage1.AutoScrollMinSize = new System.Drawing.Size(0, 800);
            tabPage1.BackColor = System.Drawing.Color.White;
            tabPage1.Controls.Add(button34);
            tabPage1.Controls.Add(button35);
            tabPage1.Controls.Add(button36);
            tabPage1.Controls.Add(button37);
            tabPage1.Controls.Add(button30);
            tabPage1.Controls.Add(button31);
            tabPage1.Controls.Add(button32);
            tabPage1.Controls.Add(button33);
            tabPage1.Controls.Add(button26);
            tabPage1.Controls.Add(button27);
            tabPage1.Controls.Add(button28);
            tabPage1.Controls.Add(button29);
            tabPage1.Controls.Add(button22);
            tabPage1.Controls.Add(button23);
            tabPage1.Controls.Add(button24);
            tabPage1.Controls.Add(button25);
            tabPage1.Controls.Add(button18);
            tabPage1.Controls.Add(button19);
            tabPage1.Controls.Add(button20);
            tabPage1.Controls.Add(button21);
            tabPage1.Controls.Add(button14);
            tabPage1.Controls.Add(button15);
            tabPage1.Controls.Add(button16);
            tabPage1.Controls.Add(button17);
            tabPage1.Controls.Add(button13);
            tabPage1.Controls.Add(button12);
            tabPage1.Controls.Add(button11);
            tabPage1.Controls.Add(button10);
            tabPage1.Controls.Add(button9);
            tabPage1.Controls.Add(button8);
            tabPage1.Controls.Add(label2);
            tabPage1.Controls.Add(label1);
            tabPage1.Controls.Add(btn_test2);
            tabPage1.Controls.Add(btn_test);
            tabPage1.Location = new System.Drawing.Point(4, 34);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new System.Windows.Forms.Padding(3);
            tabPage1.Size = new System.Drawing.Size(410, 339);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "와플";
            // 
            // button34
            // 
            button34.BackColor = System.Drawing.Color.White;
            button34.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button34.ForeColor = System.Drawing.Color.Crimson;
            button34.Location = new System.Drawing.Point(299, 682);
            button34.Name = "button34";
            button34.Size = new System.Drawing.Size(78, 65);
            button34.TabIndex = 34;
            button34.Text = "[품절]";
            button34.UseVisualStyleBackColor = false;
            // 
            // button35
            // 
            button35.BackColor = System.Drawing.Color.White;
            button35.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button35.ForeColor = System.Drawing.Color.Crimson;
            button35.Location = new System.Drawing.Point(209, 682);
            button35.Name = "button35";
            button35.Size = new System.Drawing.Size(78, 65);
            button35.TabIndex = 33;
            button35.Text = "[품절]";
            button35.UseVisualStyleBackColor = false;
            // 
            // button36
            // 
            button36.BackColor = System.Drawing.Color.White;
            button36.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button36.ForeColor = System.Drawing.Color.Crimson;
            button36.Location = new System.Drawing.Point(114, 682);
            button36.Name = "button36";
            button36.Size = new System.Drawing.Size(78, 65);
            button36.TabIndex = 32;
            button36.Text = "[품절]";
            button36.UseVisualStyleBackColor = false;
            // 
            // button37
            // 
            button37.BackColor = System.Drawing.Color.White;
            button37.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button37.ForeColor = System.Drawing.Color.Crimson;
            button37.Location = new System.Drawing.Point(16, 682);
            button37.Name = "button37";
            button37.Size = new System.Drawing.Size(78, 65);
            button37.TabIndex = 31;
            button37.Text = "[품절]";
            button37.UseVisualStyleBackColor = false;
            // 
            // button30
            // 
            button30.BackColor = System.Drawing.Color.White;
            button30.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button30.ForeColor = System.Drawing.Color.Crimson;
            button30.Location = new System.Drawing.Point(299, 593);
            button30.Name = "button30";
            button30.Size = new System.Drawing.Size(78, 65);
            button30.TabIndex = 30;
            button30.Text = "[품절]";
            button30.UseVisualStyleBackColor = false;
            // 
            // button31
            // 
            button31.BackColor = System.Drawing.Color.White;
            button31.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button31.ForeColor = System.Drawing.Color.Crimson;
            button31.Location = new System.Drawing.Point(209, 593);
            button31.Name = "button31";
            button31.Size = new System.Drawing.Size(78, 65);
            button31.TabIndex = 29;
            button31.Text = "[품절]";
            button31.UseVisualStyleBackColor = false;
            // 
            // button32
            // 
            button32.BackColor = System.Drawing.Color.White;
            button32.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button32.ForeColor = System.Drawing.Color.Crimson;
            button32.Location = new System.Drawing.Point(114, 593);
            button32.Name = "button32";
            button32.Size = new System.Drawing.Size(78, 65);
            button32.TabIndex = 28;
            button32.Text = "[품절]";
            button32.UseVisualStyleBackColor = false;
            // 
            // button33
            // 
            button33.BackColor = System.Drawing.Color.White;
            button33.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button33.ForeColor = System.Drawing.Color.Crimson;
            button33.Location = new System.Drawing.Point(16, 593);
            button33.Name = "button33";
            button33.Size = new System.Drawing.Size(78, 65);
            button33.TabIndex = 27;
            button33.Text = "[품절]";
            button33.UseVisualStyleBackColor = false;
            // 
            // button26
            // 
            button26.BackColor = System.Drawing.Color.White;
            button26.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button26.ForeColor = System.Drawing.Color.Crimson;
            button26.Location = new System.Drawing.Point(299, 508);
            button26.Name = "button26";
            button26.Size = new System.Drawing.Size(78, 65);
            button26.TabIndex = 26;
            button26.Text = "[품절]";
            button26.UseVisualStyleBackColor = false;
            // 
            // button27
            // 
            button27.BackColor = System.Drawing.Color.White;
            button27.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button27.ForeColor = System.Drawing.Color.Crimson;
            button27.Location = new System.Drawing.Point(209, 508);
            button27.Name = "button27";
            button27.Size = new System.Drawing.Size(78, 65);
            button27.TabIndex = 25;
            button27.Text = "[품절]";
            button27.UseVisualStyleBackColor = false;
            // 
            // button28
            // 
            button28.BackColor = System.Drawing.Color.White;
            button28.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button28.ForeColor = System.Drawing.Color.Crimson;
            button28.Location = new System.Drawing.Point(114, 508);
            button28.Name = "button28";
            button28.Size = new System.Drawing.Size(78, 65);
            button28.TabIndex = 24;
            button28.Text = "[품절]";
            button28.UseVisualStyleBackColor = false;
            // 
            // button29
            // 
            button29.BackColor = System.Drawing.Color.White;
            button29.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button29.ForeColor = System.Drawing.Color.Crimson;
            button29.Location = new System.Drawing.Point(16, 508);
            button29.Name = "button29";
            button29.Size = new System.Drawing.Size(78, 65);
            button29.TabIndex = 23;
            button29.Text = "[품절]";
            button29.UseVisualStyleBackColor = false;
            // 
            // button22
            // 
            button22.BackColor = System.Drawing.Color.White;
            button22.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button22.ForeColor = System.Drawing.Color.Crimson;
            button22.Location = new System.Drawing.Point(299, 420);
            button22.Name = "button22";
            button22.Size = new System.Drawing.Size(78, 65);
            button22.TabIndex = 22;
            button22.Text = "[품절]";
            button22.UseVisualStyleBackColor = false;
            // 
            // button23
            // 
            button23.BackColor = System.Drawing.Color.White;
            button23.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button23.ForeColor = System.Drawing.Color.Crimson;
            button23.Location = new System.Drawing.Point(209, 420);
            button23.Name = "button23";
            button23.Size = new System.Drawing.Size(78, 65);
            button23.TabIndex = 21;
            button23.Text = "[품절]";
            button23.UseVisualStyleBackColor = false;
            // 
            // button24
            // 
            button24.BackColor = System.Drawing.Color.White;
            button24.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button24.ForeColor = System.Drawing.Color.Crimson;
            button24.Location = new System.Drawing.Point(114, 420);
            button24.Name = "button24";
            button24.Size = new System.Drawing.Size(78, 65);
            button24.TabIndex = 20;
            button24.Text = "[품절]";
            button24.UseVisualStyleBackColor = false;
            // 
            // button25
            // 
            button25.BackColor = System.Drawing.Color.White;
            button25.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button25.ForeColor = System.Drawing.Color.Crimson;
            button25.Location = new System.Drawing.Point(16, 420);
            button25.Name = "button25";
            button25.Size = new System.Drawing.Size(78, 65);
            button25.TabIndex = 19;
            button25.Text = "[품절]";
            button25.UseVisualStyleBackColor = false;
            // 
            // button18
            // 
            button18.BackColor = System.Drawing.Color.White;
            button18.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button18.ForeColor = System.Drawing.Color.Crimson;
            button18.Location = new System.Drawing.Point(299, 329);
            button18.Name = "button18";
            button18.Size = new System.Drawing.Size(78, 65);
            button18.TabIndex = 18;
            button18.Text = "[품절]";
            button18.UseVisualStyleBackColor = false;
            // 
            // button19
            // 
            button19.BackColor = System.Drawing.Color.White;
            button19.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button19.ForeColor = System.Drawing.Color.Crimson;
            button19.Location = new System.Drawing.Point(209, 329);
            button19.Name = "button19";
            button19.Size = new System.Drawing.Size(78, 65);
            button19.TabIndex = 17;
            button19.Text = "[품절]";
            button19.UseVisualStyleBackColor = false;
            // 
            // button20
            // 
            button20.BackColor = System.Drawing.Color.White;
            button20.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button20.ForeColor = System.Drawing.Color.Crimson;
            button20.Location = new System.Drawing.Point(114, 329);
            button20.Name = "button20";
            button20.Size = new System.Drawing.Size(78, 65);
            button20.TabIndex = 16;
            button20.Text = "[품절]";
            button20.UseVisualStyleBackColor = false;
            // 
            // button21
            // 
            button21.BackColor = System.Drawing.Color.White;
            button21.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button21.ForeColor = System.Drawing.Color.Crimson;
            button21.Location = new System.Drawing.Point(16, 329);
            button21.Name = "button21";
            button21.Size = new System.Drawing.Size(78, 65);
            button21.TabIndex = 15;
            button21.Text = "[품절]";
            button21.UseVisualStyleBackColor = false;
            button21.Click += button21_Click;
            // 
            // button14
            // 
            button14.BackColor = System.Drawing.Color.White;
            button14.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button14.ForeColor = System.Drawing.Color.Crimson;
            button14.Location = new System.Drawing.Point(299, 229);
            button14.Name = "button14";
            button14.Size = new System.Drawing.Size(78, 65);
            button14.TabIndex = 14;
            button14.Text = "[품절]";
            button14.UseVisualStyleBackColor = false;
            button14.Click += button14_Click;
            // 
            // button15
            // 
            button15.BackColor = System.Drawing.Color.White;
            button15.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button15.ForeColor = System.Drawing.Color.Crimson;
            button15.Location = new System.Drawing.Point(209, 229);
            button15.Name = "button15";
            button15.Size = new System.Drawing.Size(78, 65);
            button15.TabIndex = 13;
            button15.Text = "[품절]";
            button15.UseVisualStyleBackColor = false;
            button15.Click += button15_Click;
            // 
            // button16
            // 
            button16.BackColor = System.Drawing.Color.White;
            button16.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button16.ForeColor = System.Drawing.Color.Crimson;
            button16.Location = new System.Drawing.Point(114, 229);
            button16.Name = "button16";
            button16.Size = new System.Drawing.Size(78, 65);
            button16.TabIndex = 12;
            button16.Text = "[품절]";
            button16.UseVisualStyleBackColor = false;
            button16.Click += button16_Click;
            // 
            // button17
            // 
            button17.BackColor = System.Drawing.Color.White;
            button17.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button17.ForeColor = System.Drawing.Color.Crimson;
            button17.Location = new System.Drawing.Point(16, 229);
            button17.Name = "button17";
            button17.Size = new System.Drawing.Size(78, 65);
            button17.TabIndex = 11;
            button17.Text = "[품절]";
            button17.UseVisualStyleBackColor = false;
            button17.Click += button17_Click;
            // 
            // button13
            // 
            button13.BackColor = System.Drawing.Color.White;
            button13.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button13.ForeColor = System.Drawing.Color.Crimson;
            button13.Location = new System.Drawing.Point(299, 130);
            button13.Name = "button13";
            button13.Size = new System.Drawing.Size(78, 65);
            button13.TabIndex = 10;
            button13.Text = "[품절]";
            button13.UseVisualStyleBackColor = false;
            button13.Click += button13_Click;
            // 
            // button12
            // 
            button12.BackColor = System.Drawing.Color.White;
            button12.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button12.ForeColor = System.Drawing.Color.Crimson;
            button12.Location = new System.Drawing.Point(209, 130);
            button12.Name = "button12";
            button12.Size = new System.Drawing.Size(78, 65);
            button12.TabIndex = 9;
            button12.Text = "[품절]";
            button12.UseVisualStyleBackColor = false;
            button12.Click += button12_Click;
            // 
            // button11
            // 
            button11.BackColor = System.Drawing.Color.White;
            button11.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button11.ForeColor = System.Drawing.Color.Crimson;
            button11.Location = new System.Drawing.Point(114, 130);
            button11.Name = "button11";
            button11.Size = new System.Drawing.Size(78, 65);
            button11.TabIndex = 8;
            button11.Text = "[품절]";
            button11.UseVisualStyleBackColor = false;
            button11.Click += button11_Click;
            // 
            // button10
            // 
            button10.BackColor = System.Drawing.Color.White;
            button10.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button10.ForeColor = System.Drawing.Color.Crimson;
            button10.Location = new System.Drawing.Point(16, 130);
            button10.Name = "button10";
            button10.Size = new System.Drawing.Size(78, 65);
            button10.TabIndex = 7;
            button10.Text = "[품절]";
            button10.UseVisualStyleBackColor = false;
            button10.Click += button10_Click;
            // 
            // button9
            // 
            button9.BackColor = System.Drawing.Color.White;
            button9.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button9.ForeColor = System.Drawing.Color.Crimson;
            button9.Location = new System.Drawing.Point(306, 25);
            button9.Name = "button9";
            button9.Size = new System.Drawing.Size(71, 64);
            button9.TabIndex = 6;
            button9.Text = "[품절]";
            button9.UseVisualStyleBackColor = false;
            button9.Click += button9_Click;
            // 
            // button8
            // 
            button8.BackColor = System.Drawing.Color.White;
            button8.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button8.ForeColor = System.Drawing.Color.Crimson;
            button8.Location = new System.Drawing.Point(216, 25);
            button8.Name = "button8";
            button8.Size = new System.Drawing.Size(71, 64);
            button8.TabIndex = 5;
            button8.Text = "[품절]";
            button8.UseVisualStyleBackColor = false;
            button8.Click += button8_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new System.Drawing.Point(135, 96);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(35, 15);
            label2.TabIndex = 3;
            label2.Text = "4500";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new System.Drawing.Point(38, 96);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(35, 15);
            label1.TabIndex = 2;
            label1.Text = "3500";
            // 
            // btn_test2
            // 
            btn_test2.Location = new System.Drawing.Point(114, 25);
            btn_test2.Name = "btn_test2";
            btn_test2.Size = new System.Drawing.Size(75, 68);
            btn_test2.TabIndex = 1;
            btn_test2.Text = "테스트메뉴2";
            btn_test2.UseVisualStyleBackColor = true;
            btn_test2.Click += btn_test2_Click;
            // 
            // btn_test
            // 
            btn_test.Location = new System.Drawing.Point(16, 25);
            btn_test.Name = "btn_test";
            btn_test.Size = new System.Drawing.Size(78, 68);
            btn_test.TabIndex = 0;
            btn_test.Text = "테스트메뉴1";
            btn_test.UseVisualStyleBackColor = true;
            btn_test.Click += btn_test_Click;
            // 
            // tabPage2
            // 
            tabPage2.BackColor = System.Drawing.Color.White;
            tabPage2.Controls.Add(button7);
            tabPage2.Controls.Add(button39);
            tabPage2.Controls.Add(button40);
            tabPage2.Controls.Add(button41);
            tabPage2.Controls.Add(button42);
            tabPage2.Controls.Add(button43);
            tabPage2.Controls.Add(button44);
            tabPage2.Controls.Add(button45);
            tabPage2.Controls.Add(button46);
            tabPage2.Controls.Add(button47);
            tabPage2.Controls.Add(button48);
            tabPage2.Controls.Add(button49);
            tabPage2.Location = new System.Drawing.Point(4, 34);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new System.Windows.Forms.Padding(3);
            tabPage2.Size = new System.Drawing.Size(410, 339);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "아이스와플";
            // 
            // button7
            // 
            button7.BackColor = System.Drawing.Color.White;
            button7.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button7.ForeColor = System.Drawing.Color.Crimson;
            button7.Location = new System.Drawing.Point(308, 236);
            button7.Name = "button7";
            button7.Size = new System.Drawing.Size(78, 65);
            button7.TabIndex = 30;
            button7.Text = "[품절]";
            button7.UseVisualStyleBackColor = false;
            // 
            // button39
            // 
            button39.BackColor = System.Drawing.Color.White;
            button39.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button39.ForeColor = System.Drawing.Color.Crimson;
            button39.Location = new System.Drawing.Point(218, 236);
            button39.Name = "button39";
            button39.Size = new System.Drawing.Size(78, 65);
            button39.TabIndex = 29;
            button39.Text = "[품절]";
            button39.UseVisualStyleBackColor = false;
            // 
            // button40
            // 
            button40.BackColor = System.Drawing.Color.White;
            button40.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button40.ForeColor = System.Drawing.Color.Crimson;
            button40.Location = new System.Drawing.Point(123, 236);
            button40.Name = "button40";
            button40.Size = new System.Drawing.Size(78, 65);
            button40.TabIndex = 28;
            button40.Text = "[품절]";
            button40.UseVisualStyleBackColor = false;
            // 
            // button41
            // 
            button41.BackColor = System.Drawing.Color.White;
            button41.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button41.ForeColor = System.Drawing.Color.Crimson;
            button41.Location = new System.Drawing.Point(25, 236);
            button41.Name = "button41";
            button41.Size = new System.Drawing.Size(78, 65);
            button41.TabIndex = 27;
            button41.Text = "[품절]";
            button41.UseVisualStyleBackColor = false;
            // 
            // button42
            // 
            button42.BackColor = System.Drawing.Color.White;
            button42.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button42.ForeColor = System.Drawing.Color.Crimson;
            button42.Location = new System.Drawing.Point(308, 136);
            button42.Name = "button42";
            button42.Size = new System.Drawing.Size(78, 65);
            button42.TabIndex = 26;
            button42.Text = "[품절]";
            button42.UseVisualStyleBackColor = false;
            // 
            // button43
            // 
            button43.BackColor = System.Drawing.Color.White;
            button43.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button43.ForeColor = System.Drawing.Color.Crimson;
            button43.Location = new System.Drawing.Point(218, 136);
            button43.Name = "button43";
            button43.Size = new System.Drawing.Size(78, 65);
            button43.TabIndex = 25;
            button43.Text = "[품절]";
            button43.UseVisualStyleBackColor = false;
            // 
            // button44
            // 
            button44.BackColor = System.Drawing.Color.White;
            button44.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button44.ForeColor = System.Drawing.Color.Crimson;
            button44.Location = new System.Drawing.Point(123, 136);
            button44.Name = "button44";
            button44.Size = new System.Drawing.Size(78, 65);
            button44.TabIndex = 24;
            button44.Text = "[품절]";
            button44.UseVisualStyleBackColor = false;
            // 
            // button45
            // 
            button45.BackColor = System.Drawing.Color.White;
            button45.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button45.ForeColor = System.Drawing.Color.Crimson;
            button45.Location = new System.Drawing.Point(25, 136);
            button45.Name = "button45";
            button45.Size = new System.Drawing.Size(78, 65);
            button45.TabIndex = 23;
            button45.Text = "[품절]";
            button45.UseVisualStyleBackColor = false;
            // 
            // button46
            // 
            button46.BackColor = System.Drawing.Color.White;
            button46.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button46.ForeColor = System.Drawing.Color.Crimson;
            button46.Location = new System.Drawing.Point(308, 37);
            button46.Name = "button46";
            button46.Size = new System.Drawing.Size(78, 65);
            button46.TabIndex = 22;
            button46.Text = "[품절]";
            button46.UseVisualStyleBackColor = false;
            // 
            // button47
            // 
            button47.BackColor = System.Drawing.Color.White;
            button47.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button47.ForeColor = System.Drawing.Color.Crimson;
            button47.Location = new System.Drawing.Point(218, 37);
            button47.Name = "button47";
            button47.Size = new System.Drawing.Size(78, 65);
            button47.TabIndex = 21;
            button47.Text = "[품절]";
            button47.UseVisualStyleBackColor = false;
            // 
            // button48
            // 
            button48.BackColor = System.Drawing.Color.White;
            button48.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button48.ForeColor = System.Drawing.Color.Crimson;
            button48.Location = new System.Drawing.Point(123, 37);
            button48.Name = "button48";
            button48.Size = new System.Drawing.Size(78, 65);
            button48.TabIndex = 20;
            button48.Text = "[품절]";
            button48.UseVisualStyleBackColor = false;
            // 
            // button49
            // 
            button49.BackColor = System.Drawing.Color.White;
            button49.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button49.ForeColor = System.Drawing.Color.Crimson;
            button49.Location = new System.Drawing.Point(25, 37);
            button49.Name = "button49";
            button49.Size = new System.Drawing.Size(78, 65);
            button49.TabIndex = 19;
            button49.Text = "[품절]";
            button49.UseVisualStyleBackColor = false;
            // 
            // tabPage3
            // 
            tabPage3.BackColor = System.Drawing.Color.White;
            tabPage3.Controls.Add(button50);
            tabPage3.Controls.Add(button51);
            tabPage3.Controls.Add(button52);
            tabPage3.Controls.Add(button53);
            tabPage3.Controls.Add(button54);
            tabPage3.Controls.Add(button55);
            tabPage3.Controls.Add(button56);
            tabPage3.Controls.Add(button57);
            tabPage3.Controls.Add(button58);
            tabPage3.Controls.Add(button59);
            tabPage3.Controls.Add(button60);
            tabPage3.Controls.Add(button61);
            tabPage3.Location = new System.Drawing.Point(4, 34);
            tabPage3.Name = "tabPage3";
            tabPage3.Padding = new System.Windows.Forms.Padding(3);
            tabPage3.Size = new System.Drawing.Size(410, 339);
            tabPage3.TabIndex = 2;
            tabPage3.Text = "커피";
            // 
            // button50
            // 
            button50.BackColor = System.Drawing.Color.White;
            button50.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button50.ForeColor = System.Drawing.Color.Crimson;
            button50.Location = new System.Drawing.Point(308, 236);
            button50.Name = "button50";
            button50.Size = new System.Drawing.Size(78, 65);
            button50.TabIndex = 30;
            button50.Text = "[품절]";
            button50.UseVisualStyleBackColor = false;
            // 
            // button51
            // 
            button51.BackColor = System.Drawing.Color.White;
            button51.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button51.ForeColor = System.Drawing.Color.Crimson;
            button51.Location = new System.Drawing.Point(218, 236);
            button51.Name = "button51";
            button51.Size = new System.Drawing.Size(78, 65);
            button51.TabIndex = 29;
            button51.Text = "[품절]";
            button51.UseVisualStyleBackColor = false;
            // 
            // button52
            // 
            button52.BackColor = System.Drawing.Color.White;
            button52.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button52.ForeColor = System.Drawing.Color.Crimson;
            button52.Location = new System.Drawing.Point(123, 236);
            button52.Name = "button52";
            button52.Size = new System.Drawing.Size(78, 65);
            button52.TabIndex = 28;
            button52.Text = "[품절]";
            button52.UseVisualStyleBackColor = false;
            // 
            // button53
            // 
            button53.BackColor = System.Drawing.Color.White;
            button53.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button53.ForeColor = System.Drawing.Color.Crimson;
            button53.Location = new System.Drawing.Point(25, 236);
            button53.Name = "button53";
            button53.Size = new System.Drawing.Size(78, 65);
            button53.TabIndex = 27;
            button53.Text = "[품절]";
            button53.UseVisualStyleBackColor = false;
            // 
            // button54
            // 
            button54.BackColor = System.Drawing.Color.White;
            button54.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button54.ForeColor = System.Drawing.Color.Crimson;
            button54.Location = new System.Drawing.Point(308, 136);
            button54.Name = "button54";
            button54.Size = new System.Drawing.Size(78, 65);
            button54.TabIndex = 26;
            button54.Text = "[품절]";
            button54.UseVisualStyleBackColor = false;
            // 
            // button55
            // 
            button55.BackColor = System.Drawing.Color.White;
            button55.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button55.ForeColor = System.Drawing.Color.Crimson;
            button55.Location = new System.Drawing.Point(218, 136);
            button55.Name = "button55";
            button55.Size = new System.Drawing.Size(78, 65);
            button55.TabIndex = 25;
            button55.Text = "[품절]";
            button55.UseVisualStyleBackColor = false;
            // 
            // button56
            // 
            button56.BackColor = System.Drawing.Color.White;
            button56.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button56.ForeColor = System.Drawing.Color.Crimson;
            button56.Location = new System.Drawing.Point(123, 136);
            button56.Name = "button56";
            button56.Size = new System.Drawing.Size(78, 65);
            button56.TabIndex = 24;
            button56.Text = "[품절]";
            button56.UseVisualStyleBackColor = false;
            // 
            // button57
            // 
            button57.BackColor = System.Drawing.Color.White;
            button57.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button57.ForeColor = System.Drawing.Color.Crimson;
            button57.Location = new System.Drawing.Point(25, 136);
            button57.Name = "button57";
            button57.Size = new System.Drawing.Size(78, 65);
            button57.TabIndex = 23;
            button57.Text = "[품절]";
            button57.UseVisualStyleBackColor = false;
            // 
            // button58
            // 
            button58.BackColor = System.Drawing.Color.White;
            button58.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button58.ForeColor = System.Drawing.Color.Crimson;
            button58.Location = new System.Drawing.Point(308, 37);
            button58.Name = "button58";
            button58.Size = new System.Drawing.Size(78, 65);
            button58.TabIndex = 22;
            button58.Text = "[품절]";
            button58.UseVisualStyleBackColor = false;
            // 
            // button59
            // 
            button59.BackColor = System.Drawing.Color.White;
            button59.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button59.ForeColor = System.Drawing.Color.Crimson;
            button59.Location = new System.Drawing.Point(218, 37);
            button59.Name = "button59";
            button59.Size = new System.Drawing.Size(78, 65);
            button59.TabIndex = 21;
            button59.Text = "[품절]";
            button59.UseVisualStyleBackColor = false;
            // 
            // button60
            // 
            button60.BackColor = System.Drawing.Color.White;
            button60.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button60.ForeColor = System.Drawing.Color.Crimson;
            button60.Location = new System.Drawing.Point(123, 37);
            button60.Name = "button60";
            button60.Size = new System.Drawing.Size(78, 65);
            button60.TabIndex = 20;
            button60.Text = "[품절]";
            button60.UseVisualStyleBackColor = false;
            // 
            // button61
            // 
            button61.BackColor = System.Drawing.Color.White;
            button61.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button61.ForeColor = System.Drawing.Color.Crimson;
            button61.Location = new System.Drawing.Point(25, 37);
            button61.Name = "button61";
            button61.Size = new System.Drawing.Size(78, 65);
            button61.TabIndex = 19;
            button61.Text = "[품절]";
            button61.UseVisualStyleBackColor = false;
            // 
            // tabPage4
            // 
            tabPage4.Controls.Add(button62);
            tabPage4.Controls.Add(button63);
            tabPage4.Controls.Add(button64);
            tabPage4.Controls.Add(button65);
            tabPage4.Controls.Add(button66);
            tabPage4.Controls.Add(button67);
            tabPage4.Controls.Add(button68);
            tabPage4.Controls.Add(button69);
            tabPage4.Controls.Add(button70);
            tabPage4.Controls.Add(button71);
            tabPage4.Controls.Add(button72);
            tabPage4.Controls.Add(button73);
            tabPage4.Location = new System.Drawing.Point(4, 34);
            tabPage4.Name = "tabPage4";
            tabPage4.Padding = new System.Windows.Forms.Padding(3);
            tabPage4.Size = new System.Drawing.Size(410, 339);
            tabPage4.TabIndex = 3;
            tabPage4.Text = "음료";
            tabPage4.UseVisualStyleBackColor = true;
            tabPage4.Click += tabPage4_Click;
            // 
            // button62
            // 
            button62.BackColor = System.Drawing.Color.White;
            button62.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button62.ForeColor = System.Drawing.Color.Crimson;
            button62.Location = new System.Drawing.Point(308, 236);
            button62.Name = "button62";
            button62.Size = new System.Drawing.Size(78, 65);
            button62.TabIndex = 30;
            button62.Text = "[품절]";
            button62.UseVisualStyleBackColor = false;
            // 
            // button63
            // 
            button63.BackColor = System.Drawing.Color.White;
            button63.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button63.ForeColor = System.Drawing.Color.Crimson;
            button63.Location = new System.Drawing.Point(218, 236);
            button63.Name = "button63";
            button63.Size = new System.Drawing.Size(78, 65);
            button63.TabIndex = 29;
            button63.Text = "[품절]";
            button63.UseVisualStyleBackColor = false;
            // 
            // button64
            // 
            button64.BackColor = System.Drawing.Color.White;
            button64.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button64.ForeColor = System.Drawing.Color.Crimson;
            button64.Location = new System.Drawing.Point(123, 236);
            button64.Name = "button64";
            button64.Size = new System.Drawing.Size(78, 65);
            button64.TabIndex = 28;
            button64.Text = "[품절]";
            button64.UseVisualStyleBackColor = false;
            // 
            // button65
            // 
            button65.BackColor = System.Drawing.Color.White;
            button65.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button65.ForeColor = System.Drawing.Color.Crimson;
            button65.Location = new System.Drawing.Point(25, 236);
            button65.Name = "button65";
            button65.Size = new System.Drawing.Size(78, 65);
            button65.TabIndex = 27;
            button65.Text = "[품절]";
            button65.UseVisualStyleBackColor = false;
            // 
            // button66
            // 
            button66.BackColor = System.Drawing.Color.White;
            button66.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button66.ForeColor = System.Drawing.Color.Crimson;
            button66.Location = new System.Drawing.Point(308, 136);
            button66.Name = "button66";
            button66.Size = new System.Drawing.Size(78, 65);
            button66.TabIndex = 26;
            button66.Text = "[품절]";
            button66.UseVisualStyleBackColor = false;
            // 
            // button67
            // 
            button67.BackColor = System.Drawing.Color.White;
            button67.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button67.ForeColor = System.Drawing.Color.Crimson;
            button67.Location = new System.Drawing.Point(218, 136);
            button67.Name = "button67";
            button67.Size = new System.Drawing.Size(78, 65);
            button67.TabIndex = 25;
            button67.Text = "[품절]";
            button67.UseVisualStyleBackColor = false;
            // 
            // button68
            // 
            button68.BackColor = System.Drawing.Color.White;
            button68.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button68.ForeColor = System.Drawing.Color.Crimson;
            button68.Location = new System.Drawing.Point(123, 136);
            button68.Name = "button68";
            button68.Size = new System.Drawing.Size(78, 65);
            button68.TabIndex = 24;
            button68.Text = "[품절]";
            button68.UseVisualStyleBackColor = false;
            // 
            // button69
            // 
            button69.BackColor = System.Drawing.Color.White;
            button69.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button69.ForeColor = System.Drawing.Color.Crimson;
            button69.Location = new System.Drawing.Point(25, 136);
            button69.Name = "button69";
            button69.Size = new System.Drawing.Size(78, 65);
            button69.TabIndex = 23;
            button69.Text = "[품절]";
            button69.UseVisualStyleBackColor = false;
            // 
            // button70
            // 
            button70.BackColor = System.Drawing.Color.White;
            button70.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button70.ForeColor = System.Drawing.Color.Crimson;
            button70.Location = new System.Drawing.Point(308, 37);
            button70.Name = "button70";
            button70.Size = new System.Drawing.Size(78, 65);
            button70.TabIndex = 22;
            button70.Text = "[품절]";
            button70.UseVisualStyleBackColor = false;
            // 
            // button71
            // 
            button71.BackColor = System.Drawing.Color.White;
            button71.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button71.ForeColor = System.Drawing.Color.Crimson;
            button71.Location = new System.Drawing.Point(218, 37);
            button71.Name = "button71";
            button71.Size = new System.Drawing.Size(78, 65);
            button71.TabIndex = 21;
            button71.Text = "[품절]";
            button71.UseVisualStyleBackColor = false;
            // 
            // button72
            // 
            button72.BackColor = System.Drawing.Color.White;
            button72.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button72.ForeColor = System.Drawing.Color.Crimson;
            button72.Location = new System.Drawing.Point(123, 37);
            button72.Name = "button72";
            button72.Size = new System.Drawing.Size(78, 65);
            button72.TabIndex = 20;
            button72.Text = "[품절]";
            button72.UseVisualStyleBackColor = false;
            // 
            // button73
            // 
            button73.BackColor = System.Drawing.Color.White;
            button73.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button73.ForeColor = System.Drawing.Color.Crimson;
            button73.Location = new System.Drawing.Point(25, 37);
            button73.Name = "button73";
            button73.Size = new System.Drawing.Size(78, 65);
            button73.TabIndex = 19;
            button73.Text = "[품절]";
            button73.UseVisualStyleBackColor = false;
            // 
            // tabPage5
            // 
            tabPage5.BackColor = System.Drawing.Color.White;
            tabPage5.Controls.Add(button74);
            tabPage5.Controls.Add(button75);
            tabPage5.Controls.Add(button76);
            tabPage5.Controls.Add(button77);
            tabPage5.Controls.Add(button78);
            tabPage5.Controls.Add(button79);
            tabPage5.Controls.Add(button80);
            tabPage5.Controls.Add(button81);
            tabPage5.Controls.Add(button82);
            tabPage5.Controls.Add(button83);
            tabPage5.Controls.Add(button84);
            tabPage5.Controls.Add(button85);
            tabPage5.Controls.Add(button4);
            tabPage5.Location = new System.Drawing.Point(4, 34);
            tabPage5.Name = "tabPage5";
            tabPage5.Padding = new System.Windows.Forms.Padding(3);
            tabPage5.Size = new System.Drawing.Size(410, 339);
            tabPage5.TabIndex = 4;
            tabPage5.Text = "아이스음료";
            // 
            // button74
            // 
            button74.BackColor = System.Drawing.Color.White;
            button74.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button74.ForeColor = System.Drawing.Color.Crimson;
            button74.Location = new System.Drawing.Point(308, 236);
            button74.Name = "button74";
            button74.Size = new System.Drawing.Size(78, 65);
            button74.TabIndex = 30;
            button74.Text = "[품절]";
            button74.UseVisualStyleBackColor = false;
            // 
            // button75
            // 
            button75.BackColor = System.Drawing.Color.White;
            button75.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button75.ForeColor = System.Drawing.Color.Crimson;
            button75.Location = new System.Drawing.Point(218, 236);
            button75.Name = "button75";
            button75.Size = new System.Drawing.Size(78, 65);
            button75.TabIndex = 29;
            button75.Text = "[품절]";
            button75.UseVisualStyleBackColor = false;
            // 
            // button76
            // 
            button76.BackColor = System.Drawing.Color.White;
            button76.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button76.ForeColor = System.Drawing.Color.Crimson;
            button76.Location = new System.Drawing.Point(123, 236);
            button76.Name = "button76";
            button76.Size = new System.Drawing.Size(78, 65);
            button76.TabIndex = 28;
            button76.Text = "[품절]";
            button76.UseVisualStyleBackColor = false;
            // 
            // button77
            // 
            button77.BackColor = System.Drawing.Color.White;
            button77.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button77.ForeColor = System.Drawing.Color.Crimson;
            button77.Location = new System.Drawing.Point(25, 236);
            button77.Name = "button77";
            button77.Size = new System.Drawing.Size(78, 65);
            button77.TabIndex = 27;
            button77.Text = "[품절]";
            button77.UseVisualStyleBackColor = false;
            // 
            // button78
            // 
            button78.BackColor = System.Drawing.Color.White;
            button78.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button78.ForeColor = System.Drawing.Color.Crimson;
            button78.Location = new System.Drawing.Point(308, 136);
            button78.Name = "button78";
            button78.Size = new System.Drawing.Size(78, 65);
            button78.TabIndex = 26;
            button78.Text = "[품절]";
            button78.UseVisualStyleBackColor = false;
            // 
            // button79
            // 
            button79.BackColor = System.Drawing.Color.White;
            button79.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button79.ForeColor = System.Drawing.Color.Crimson;
            button79.Location = new System.Drawing.Point(218, 136);
            button79.Name = "button79";
            button79.Size = new System.Drawing.Size(78, 65);
            button79.TabIndex = 25;
            button79.Text = "[품절]";
            button79.UseVisualStyleBackColor = false;
            // 
            // button80
            // 
            button80.BackColor = System.Drawing.Color.White;
            button80.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button80.ForeColor = System.Drawing.Color.Crimson;
            button80.Location = new System.Drawing.Point(123, 136);
            button80.Name = "button80";
            button80.Size = new System.Drawing.Size(78, 65);
            button80.TabIndex = 24;
            button80.Text = "[품절]";
            button80.UseVisualStyleBackColor = false;
            // 
            // button81
            // 
            button81.BackColor = System.Drawing.Color.White;
            button81.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button81.ForeColor = System.Drawing.Color.Crimson;
            button81.Location = new System.Drawing.Point(25, 136);
            button81.Name = "button81";
            button81.Size = new System.Drawing.Size(78, 65);
            button81.TabIndex = 23;
            button81.Text = "[품절]";
            button81.UseVisualStyleBackColor = false;
            // 
            // button82
            // 
            button82.BackColor = System.Drawing.Color.White;
            button82.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button82.ForeColor = System.Drawing.Color.Crimson;
            button82.Location = new System.Drawing.Point(308, 37);
            button82.Name = "button82";
            button82.Size = new System.Drawing.Size(78, 65);
            button82.TabIndex = 22;
            button82.Text = "[품절]";
            button82.UseVisualStyleBackColor = false;
            // 
            // button83
            // 
            button83.BackColor = System.Drawing.Color.White;
            button83.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button83.ForeColor = System.Drawing.Color.Crimson;
            button83.Location = new System.Drawing.Point(218, 37);
            button83.Name = "button83";
            button83.Size = new System.Drawing.Size(78, 65);
            button83.TabIndex = 21;
            button83.Text = "[품절]";
            button83.UseVisualStyleBackColor = false;
            // 
            // button84
            // 
            button84.BackColor = System.Drawing.Color.White;
            button84.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button84.ForeColor = System.Drawing.Color.Crimson;
            button84.Location = new System.Drawing.Point(123, 37);
            button84.Name = "button84";
            button84.Size = new System.Drawing.Size(78, 65);
            button84.TabIndex = 20;
            button84.Text = "[품절]";
            button84.UseVisualStyleBackColor = false;
            // 
            // button85
            // 
            button85.BackColor = System.Drawing.Color.White;
            button85.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button85.ForeColor = System.Drawing.Color.Crimson;
            button85.Location = new System.Drawing.Point(25, 37);
            button85.Name = "button85";
            button85.Size = new System.Drawing.Size(78, 65);
            button85.TabIndex = 19;
            button85.Text = "[품절]";
            button85.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            button4.Location = new System.Drawing.Point(407, 15);
            button4.Name = "button4";
            button4.Size = new System.Drawing.Size(75, 23);
            button4.TabIndex = 1;
            button4.Text = "button4";
            button4.UseVisualStyleBackColor = true;
            // 
            // tabPage6
            // 
            tabPage6.BackColor = System.Drawing.Color.White;
            tabPage6.Controls.Add(button86);
            tabPage6.Controls.Add(button87);
            tabPage6.Controls.Add(button88);
            tabPage6.Controls.Add(button89);
            tabPage6.Controls.Add(button90);
            tabPage6.Controls.Add(button91);
            tabPage6.Controls.Add(button92);
            tabPage6.Controls.Add(button93);
            tabPage6.Controls.Add(button94);
            tabPage6.Controls.Add(button95);
            tabPage6.Controls.Add(button96);
            tabPage6.Controls.Add(button97);
            tabPage6.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            tabPage6.Location = new System.Drawing.Point(4, 34);
            tabPage6.Name = "tabPage6";
            tabPage6.Padding = new System.Windows.Forms.Padding(3);
            tabPage6.Size = new System.Drawing.Size(410, 339);
            tabPage6.TabIndex = 5;
            tabPage6.Text = "아이스크림";
            tabPage6.Click += tabPage6_Click;
            // 
            // button86
            // 
            button86.BackColor = System.Drawing.Color.White;
            button86.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button86.ForeColor = System.Drawing.Color.Crimson;
            button86.Location = new System.Drawing.Point(308, 236);
            button86.Name = "button86";
            button86.Size = new System.Drawing.Size(78, 65);
            button86.TabIndex = 30;
            button86.Text = "[품절]";
            button86.UseVisualStyleBackColor = false;
            // 
            // button87
            // 
            button87.BackColor = System.Drawing.Color.White;
            button87.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button87.ForeColor = System.Drawing.Color.Crimson;
            button87.Location = new System.Drawing.Point(218, 236);
            button87.Name = "button87";
            button87.Size = new System.Drawing.Size(78, 65);
            button87.TabIndex = 29;
            button87.Text = "[품절]";
            button87.UseVisualStyleBackColor = false;
            // 
            // button88
            // 
            button88.BackColor = System.Drawing.Color.White;
            button88.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button88.ForeColor = System.Drawing.Color.Crimson;
            button88.Location = new System.Drawing.Point(123, 236);
            button88.Name = "button88";
            button88.Size = new System.Drawing.Size(78, 65);
            button88.TabIndex = 28;
            button88.Text = "[품절]";
            button88.UseVisualStyleBackColor = false;
            // 
            // button89
            // 
            button89.BackColor = System.Drawing.Color.White;
            button89.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button89.ForeColor = System.Drawing.Color.Crimson;
            button89.Location = new System.Drawing.Point(25, 236);
            button89.Name = "button89";
            button89.Size = new System.Drawing.Size(78, 65);
            button89.TabIndex = 27;
            button89.Text = "[품절]";
            button89.UseVisualStyleBackColor = false;
            // 
            // button90
            // 
            button90.BackColor = System.Drawing.Color.White;
            button90.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button90.ForeColor = System.Drawing.Color.Crimson;
            button90.Location = new System.Drawing.Point(308, 136);
            button90.Name = "button90";
            button90.Size = new System.Drawing.Size(78, 65);
            button90.TabIndex = 26;
            button90.Text = "[품절]";
            button90.UseVisualStyleBackColor = false;
            // 
            // button91
            // 
            button91.BackColor = System.Drawing.Color.White;
            button91.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button91.ForeColor = System.Drawing.Color.Crimson;
            button91.Location = new System.Drawing.Point(218, 136);
            button91.Name = "button91";
            button91.Size = new System.Drawing.Size(78, 65);
            button91.TabIndex = 25;
            button91.Text = "[품절]";
            button91.UseVisualStyleBackColor = false;
            // 
            // button92
            // 
            button92.BackColor = System.Drawing.Color.White;
            button92.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button92.ForeColor = System.Drawing.Color.Crimson;
            button92.Location = new System.Drawing.Point(123, 136);
            button92.Name = "button92";
            button92.Size = new System.Drawing.Size(78, 65);
            button92.TabIndex = 24;
            button92.Text = "[품절]";
            button92.UseVisualStyleBackColor = false;
            // 
            // button93
            // 
            button93.BackColor = System.Drawing.Color.White;
            button93.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button93.ForeColor = System.Drawing.Color.Crimson;
            button93.Location = new System.Drawing.Point(25, 136);
            button93.Name = "button93";
            button93.Size = new System.Drawing.Size(78, 65);
            button93.TabIndex = 23;
            button93.Text = "[품절]";
            button93.UseVisualStyleBackColor = false;
            // 
            // button94
            // 
            button94.BackColor = System.Drawing.Color.White;
            button94.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button94.ForeColor = System.Drawing.Color.Crimson;
            button94.Location = new System.Drawing.Point(308, 37);
            button94.Name = "button94";
            button94.Size = new System.Drawing.Size(78, 65);
            button94.TabIndex = 22;
            button94.Text = "[품절]";
            button94.UseVisualStyleBackColor = false;
            // 
            // button95
            // 
            button95.BackColor = System.Drawing.Color.White;
            button95.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button95.ForeColor = System.Drawing.Color.Crimson;
            button95.Location = new System.Drawing.Point(218, 37);
            button95.Name = "button95";
            button95.Size = new System.Drawing.Size(78, 65);
            button95.TabIndex = 21;
            button95.Text = "[품절]";
            button95.UseVisualStyleBackColor = false;
            // 
            // button96
            // 
            button96.BackColor = System.Drawing.Color.White;
            button96.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button96.ForeColor = System.Drawing.Color.Crimson;
            button96.Location = new System.Drawing.Point(123, 37);
            button96.Name = "button96";
            button96.Size = new System.Drawing.Size(78, 65);
            button96.TabIndex = 20;
            button96.Text = "[품절]";
            button96.UseVisualStyleBackColor = false;
            // 
            // button97
            // 
            button97.BackColor = System.Drawing.Color.White;
            button97.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button97.ForeColor = System.Drawing.Color.Crimson;
            button97.Location = new System.Drawing.Point(25, 37);
            button97.Name = "button97";
            button97.Size = new System.Drawing.Size(78, 65);
            button97.TabIndex = 19;
            button97.Text = "[품절]";
            button97.UseVisualStyleBackColor = false;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.카페;
            pictureBox2.Location = new System.Drawing.Point(262, 188);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new System.Drawing.Size(78, 41);
            pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 12;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // button38
            // 
            button38.BackColor = System.Drawing.Color.Black;
            button38.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button38.ForeColor = System.Drawing.Color.White;
            button38.Location = new System.Drawing.Point(207, 182);
            button38.Name = "button38";
            button38.Size = new System.Drawing.Size(49, 52);
            button38.TabIndex = 11;
            button38.Text = "전체 취소";
            button38.UseVisualStyleBackColor = false;
            // 
            // textBox3
            // 
            textBox3.Location = new System.Drawing.Point(85, 187);
            textBox3.Name = "textBox3";
            textBox3.Size = new System.Drawing.Size(100, 23);
            textBox3.TabIndex = 10;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new System.Drawing.Font("맑은 고딕", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label4.Location = new System.Drawing.Point(12, 209);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(69, 20);
            label4.TabIndex = 9;
            label4.Text = "주문금액";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new System.Drawing.Font("맑은 고딕", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label3.ForeColor = System.Drawing.Color.Black;
            label3.Location = new System.Drawing.Point(12, 190);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(69, 20);
            label3.TabIndex = 8;
            label3.Text = "주문수량";
            // 
            // textBox2
            // 
            textBox2.Location = new System.Drawing.Point(85, 210);
            textBox2.Name = "textBox2";
            textBox2.Size = new System.Drawing.Size(100, 23);
            textBox2.TabIndex = 7;
            // 
            // btn_pay
            // 
            btn_pay.BackColor = System.Drawing.Color.Firebrick;
            btn_pay.FlatAppearance.BorderSize = 0;
            btn_pay.Font = new System.Drawing.Font("맑은 고딕", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            btn_pay.ForeColor = System.Drawing.Color.White;
            btn_pay.Location = new System.Drawing.Point(433, 188);
            btn_pay.Name = "btn_pay";
            btn_pay.Size = new System.Drawing.Size(88, 41);
            btn_pay.TabIndex = 5;
            btn_pay.Text = "카드";
            btn_pay.UseVisualStyleBackColor = false;
            btn_pay.Click += btn_pay_Click;
            // 
            // btn_cash
            // 
            btn_cash.BackColor = System.Drawing.Color.RoyalBlue;
            btn_cash.FlatAppearance.BorderColor = System.Drawing.Color.RoyalBlue;
            btn_cash.FlatAppearance.BorderSize = 0;
            btn_cash.Font = new System.Drawing.Font("맑은 고딕", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            btn_cash.ForeColor = System.Drawing.Color.White;
            btn_cash.Location = new System.Drawing.Point(346, 187);
            btn_cash.Name = "btn_cash";
            btn_cash.Size = new System.Drawing.Size(84, 41);
            btn_cash.TabIndex = 4;
            btn_cash.Text = "현금";
            btn_cash.UseVisualStyleBackColor = false;
            // 
            // listView1
            // 
            listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] { menu, num, price });
            listView1.Location = new System.Drawing.Point(1, 36);
            listView1.Name = "listView1";
            listView1.Size = new System.Drawing.Size(523, 145);
            listView1.TabIndex = 2;
            listView1.UseCompatibleStateImageBehavior = false;
            listView1.SelectedIndexChanged += listView1_SelectedIndexChanged;
            // 
            // menu
            // 
            menu.Text = " ";
            menu.Width = 200;
            // 
            // num
            // 
            num.Text = " ";
            num.Width = 150;
            // 
            // price
            // 
            price.Text = " ";
            price.Width = 150;
            // 
            // textBox1
            // 
            textBox1.BackColor = System.Drawing.Color.RoyalBlue;
            textBox1.Font = new System.Drawing.Font("맑은 고딕", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            textBox1.ForeColor = System.Drawing.Color.White;
            textBox1.Location = new System.Drawing.Point(-3, 3);
            textBox1.Multiline = true;
            textBox1.Name = "textBox1";
            textBox1.Size = new System.Drawing.Size(527, 33);
            textBox1.TabIndex = 1;
            textBox1.Text = "       메뉴                                수량                           가격";
            // 
            // button3
            // 
            button3.Location = new System.Drawing.Point(392, 24);
            button3.Name = "button3";
            button3.Size = new System.Drawing.Size(8, 8);
            button3.TabIndex = 0;
            button3.Text = "button3";
            button3.UseVisualStyleBackColor = true;
            // 
            // contextMenuStrip1
            // 
            contextMenuStrip1.Name = "contextMenuStrip1";
            contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // Form1
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            BackColor = System.Drawing.Color.White;
            ClientSize = new System.Drawing.Size(524, 698);
            Controls.Add(splitContainer1);
            Name = "Form1";
            Text = "Form1";
            splitContainer1.Panel1.ResumeLayout(false);
            splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)splitContainer1).EndInit();
            splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            splitContainer2.Panel1.ResumeLayout(false);
            splitContainer2.Panel2.ResumeLayout(false);
            splitContainer2.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)splitContainer2).EndInit();
            splitContainer2.ResumeLayout(false);
            tabControl1.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            tabPage2.ResumeLayout(false);
            tabPage3.ResumeLayout(false);
            tabPage4.ResumeLayout(false);
            tabPage5.ResumeLayout(false);
            tabPage6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label lbmenu1;
        private System.Windows.Forms.Button btn_pay;
        private System.Windows.Forms.Button btn_cash;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader menu;
        private System.Windows.Forms.ColumnHeader num;
        private System.Windows.Forms.ColumnHeader price;
        private System.Windows.Forms.Button btn_test;
        private System.Windows.Forms.Button btn_test2;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Button button38;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.Button button43;
        private System.Windows.Forms.Button button44;
        private System.Windows.Forms.Button button45;
        private System.Windows.Forms.Button button46;
        private System.Windows.Forms.Button button47;
        private System.Windows.Forms.Button button48;
        private System.Windows.Forms.Button button49;
        private System.Windows.Forms.Button button50;
        private System.Windows.Forms.Button button51;
        private System.Windows.Forms.Button button52;
        private System.Windows.Forms.Button button53;
        private System.Windows.Forms.Button button54;
        private System.Windows.Forms.Button button55;
        private System.Windows.Forms.Button button56;
        private System.Windows.Forms.Button button57;
        private System.Windows.Forms.Button button58;
        private System.Windows.Forms.Button button59;
        private System.Windows.Forms.Button button60;
        private System.Windows.Forms.Button button61;
        private System.Windows.Forms.Button button62;
        private System.Windows.Forms.Button button63;
        private System.Windows.Forms.Button button64;
        private System.Windows.Forms.Button button65;
        private System.Windows.Forms.Button button66;
        private System.Windows.Forms.Button button67;
        private System.Windows.Forms.Button button68;
        private System.Windows.Forms.Button button69;
        private System.Windows.Forms.Button button70;
        private System.Windows.Forms.Button button71;
        private System.Windows.Forms.Button button72;
        private System.Windows.Forms.Button button73;
        private System.Windows.Forms.Button button74;
        private System.Windows.Forms.Button button75;
        private System.Windows.Forms.Button button76;
        private System.Windows.Forms.Button button77;
        private System.Windows.Forms.Button button78;
        private System.Windows.Forms.Button button79;
        private System.Windows.Forms.Button button80;
        private System.Windows.Forms.Button button81;
        private System.Windows.Forms.Button button82;
        private System.Windows.Forms.Button button83;
        private System.Windows.Forms.Button button84;
        private System.Windows.Forms.Button button85;
        private System.Windows.Forms.Button button86;
        private System.Windows.Forms.Button button87;
        private System.Windows.Forms.Button button88;
        private System.Windows.Forms.Button button89;
        private System.Windows.Forms.Button button90;
        private System.Windows.Forms.Button button91;
        private System.Windows.Forms.Button button92;
        private System.Windows.Forms.Button button93;
        private System.Windows.Forms.Button button94;
        private System.Windows.Forms.Button button95;
        private System.Windows.Forms.Button button96;
        private System.Windows.Forms.Button button97;
    }
}
