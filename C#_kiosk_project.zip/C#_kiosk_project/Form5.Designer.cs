﻿namespace pj01
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form5));
            label1 = new System.Windows.Forms.Label();
            richTextBox1 = new System.Windows.Forms.RichTextBox();
            richTextBox2 = new System.Windows.Forms.RichTextBox();
            pictureBox1 = new System.Windows.Forms.PictureBox();
            richTextBox3 = new System.Windows.Forms.RichTextBox();
            label2 = new System.Windows.Forms.Label();
            button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new System.Drawing.Font("맑은 고딕", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label1.Location = new System.Drawing.Point(182, 21);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(95, 25);
            label1.TabIndex = 0;
            label1.Text = "결제 완료";
            // 
            // richTextBox1
            // 
            richTextBox1.Font = new System.Drawing.Font("맑은 고딕", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            richTextBox1.Location = new System.Drawing.Point(-2, 95);
            richTextBox1.Name = "richTextBox1";
            richTextBox1.Size = new System.Drawing.Size(492, 497);
            richTextBox1.TabIndex = 1;
            richTextBox1.Text = "\t\t \n   \n\t\t\t   결제가 완료 되었습니다\n\t\t영수증을 가져가 주시길 바랍니다. 감사합니다.";
            // 
            // richTextBox2
            // 
            richTextBox2.BackColor = System.Drawing.Color.Silver;
            richTextBox2.Font = new System.Drawing.Font("맑은 고딕", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            richTextBox2.ForeColor = System.Drawing.Color.Red;
            richTextBox2.Location = new System.Drawing.Point(12, 242);
            richTextBox2.Name = "richTextBox2";
            richTextBox2.Size = new System.Drawing.Size(457, 225);
            richTextBox2.TabIndex = 2;
            richTextBox2.Text = "         주문번호 : 0121";
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            pictureBox1.Location = new System.Drawing.Point(127, 369);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new System.Drawing.Size(226, 21);
            pictureBox1.TabIndex = 3;
            pictureBox1.TabStop = false;
            // 
            // richTextBox3
            // 
            richTextBox3.Font = new System.Drawing.Font("맑은 고딕", 5.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            richTextBox3.Location = new System.Drawing.Point(165, 369);
            richTextBox3.Name = "richTextBox3";
            richTextBox3.Size = new System.Drawing.Size(147, 50);
            richTextBox3.TabIndex = 4;
            richTextBox3.Text = resources.GetString("richTextBox3.Text");
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new System.Drawing.Point(182, 351);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(98, 15);
            label2.TabIndex = 5;
            label2.Text = "영수증 나오는곳.";
            // 
            // button1
            // 
            button1.BackColor = System.Drawing.Color.Crimson;
            button1.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button1.ForeColor = System.Drawing.Color.Transparent;
            button1.Location = new System.Drawing.Point(137, 512);
            button1.Name = "button1";
            button1.Size = new System.Drawing.Size(175, 64);
            button1.TabIndex = 6;
            button1.Text = "확인";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // Form5
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            BackColor = System.Drawing.SystemColors.ActiveBorder;
            ClientSize = new System.Drawing.Size(481, 588);
            Controls.Add(button1);
            Controls.Add(label2);
            Controls.Add(richTextBox3);
            Controls.Add(pictureBox1);
            Controls.Add(richTextBox2);
            Controls.Add(richTextBox1);
            Controls.Add(label1);
            Name = "Form5";
            Text = "Form5";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.RichTextBox richTextBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.RichTextBox richTextBox3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
    }
}