﻿namespace pj01
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            richTextBox1 = new System.Windows.Forms.RichTextBox();
            label1 = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            button1 = new System.Windows.Forms.Button();
            label4 = new System.Windows.Forms.Label();
            label5 = new System.Windows.Forms.Label();
            label6 = new System.Windows.Forms.Label();
            label7 = new System.Windows.Forms.Label();
            button2 = new System.Windows.Forms.Button();
            button3 = new System.Windows.Forms.Button();
            button4 = new System.Windows.Forms.Button();
            pictureBox1 = new System.Windows.Forms.PictureBox();
            label8 = new System.Windows.Forms.Label();
            label9 = new System.Windows.Forms.Label();
            label10 = new System.Windows.Forms.Label();
            label11 = new System.Windows.Forms.Label();
            label12 = new System.Windows.Forms.Label();
            label13 = new System.Windows.Forms.Label();
            label14 = new System.Windows.Forms.Label();
            label15 = new System.Windows.Forms.Label();
            label16 = new System.Windows.Forms.Label();
            label17 = new System.Windows.Forms.Label();
            label18 = new System.Windows.Forms.Label();
            label19 = new System.Windows.Forms.Label();
            label20 = new System.Windows.Forms.Label();
            label21 = new System.Windows.Forms.Label();
            label22 = new System.Windows.Forms.Label();
            label23 = new System.Windows.Forms.Label();
            label24 = new System.Windows.Forms.Label();
            label25 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // richTextBox1
            // 
            richTextBox1.Font = new System.Drawing.Font("나눔바른고딕OTF", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            richTextBox1.Location = new System.Drawing.Point(-3, 52);
            richTextBox1.Name = "richTextBox1";
            richTextBox1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            richTextBox1.Size = new System.Drawing.Size(379, 93);
            richTextBox1.TabIndex = 0;
            richTextBox1.Text = "";
            richTextBox1.TextChanged += richTextBox1_TextChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = System.Drawing.Color.White;
            label1.Font = new System.Drawing.Font("맑은 고딕", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label1.Location = new System.Drawing.Point(77, 75);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(199, 20);
            label1.TabIndex = 1;
            label1.Text = "주문리스트를 확인해 주시고";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = System.Drawing.Color.White;
            label2.Font = new System.Drawing.Font("맑은 고딕", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label2.Location = new System.Drawing.Point(53, 103);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(258, 20);
            label2.TabIndex = 2;
            label2.Text = "매장식사 또는 포장을 선택해 주세요.";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = System.Drawing.SystemColors.Control;
            label3.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label3.ForeColor = System.Drawing.Color.MediumBlue;
            label3.Location = new System.Drawing.Point(26, 18);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(65, 17);
            label3.TabIndex = 3;
            label3.Text = "포장 선택";
            // 
            // button1
            // 
            button1.BackColor = System.Drawing.Color.Transparent;
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            button1.Font = new System.Drawing.Font("맑은 고딕", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button1.Location = new System.Drawing.Point(310, 8);
            button1.Name = "button1";
            button1.Size = new System.Drawing.Size(41, 38);
            button1.TabIndex = 4;
            button1.Text = "X";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new System.Drawing.Font("맑은 고딕", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label4.Location = new System.Drawing.Point(12, 394);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(63, 20);
            label4.TabIndex = 5;
            label4.Text = "총 수량:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label5.Location = new System.Drawing.Point(74, 393);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(17, 21);
            label5.TabIndex = 6;
            label5.Text = "-";
            label5.Click += label5_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label6.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            label6.Location = new System.Drawing.Point(176, 393);
            label6.Name = "label6";
            label6.Size = new System.Drawing.Size(90, 21);
            label6.TabIndex = 7;
            label6.Text = "주문 금액 :";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label7.ForeColor = System.Drawing.Color.Blue;
            label7.Location = new System.Drawing.Point(272, 394);
            label7.Name = "label7";
            label7.Size = new System.Drawing.Size(17, 21);
            label7.TabIndex = 8;
            label7.Text = "-";
            label7.Click += label7_Click;
            // 
            // button2
            // 
            button2.BackColor = System.Drawing.Color.Yellow;
            button2.FlatAppearance.BorderColor = System.Drawing.Color.Yellow;
            button2.FlatAppearance.BorderSize = 0;
            button2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            button2.Font = new System.Drawing.Font("함초롬바탕 확장", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            button2.Location = new System.Drawing.Point(13, 434);
            button2.Name = "button2";
            button2.Size = new System.Drawing.Size(116, 46);
            button2.TabIndex = 9;
            button2.Text = "매장에서 먹을래요";
            button2.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            button3.BackColor = System.Drawing.Color.Yellow;
            button3.FlatAppearance.BorderColor = System.Drawing.Color.Yellow;
            button3.FlatAppearance.BorderSize = 0;
            button3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            button3.Font = new System.Drawing.Font("함초롬바탕 확장", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            button3.Location = new System.Drawing.Point(135, 434);
            button3.Name = "button3";
            button3.Size = new System.Drawing.Size(116, 46);
            button3.TabIndex = 10;
            button3.Text = "가면서 먹을래요";
            button3.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            button4.BackColor = System.Drawing.Color.Yellow;
            button4.FlatAppearance.BorderColor = System.Drawing.Color.Yellow;
            button4.FlatAppearance.BorderSize = 0;
            button4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            button4.Font = new System.Drawing.Font("함초롬바탕 확장", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            button4.Location = new System.Drawing.Point(257, 434);
            button4.Name = "button4";
            button4.Size = new System.Drawing.Size(106, 46);
            button4.TabIndex = 11;
            button4.Text = "포장 할래요";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = System.Drawing.Color.White;
            pictureBox1.Location = new System.Drawing.Point(-3, 180);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new System.Drawing.Size(379, 210);
            pictureBox1.TabIndex = 12;
            pictureBox1.TabStop = false;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = System.Drawing.SystemColors.ActiveBorder;
            label8.Location = new System.Drawing.Point(11, 158);
            label8.Name = "label8";
            label8.Size = new System.Drawing.Size(31, 15);
            label8.TabIndex = 13;
            label8.Text = "메뉴";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new System.Drawing.Point(198, 158);
            label9.Name = "label9";
            label9.Size = new System.Drawing.Size(31, 15);
            label9.TabIndex = 14;
            label9.Text = "수량";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new System.Drawing.Point(293, 158);
            label10.Name = "label10";
            label10.Size = new System.Drawing.Size(31, 15);
            label10.TabIndex = 15;
            label10.Text = "가격";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.BackColor = System.Drawing.Color.White;
            label11.Location = new System.Drawing.Point(11, 191);
            label11.Name = "label11";
            label11.Size = new System.Drawing.Size(12, 15);
            label11.TabIndex = 16;
            label11.Text = "-";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.BackColor = System.Drawing.Color.White;
            label12.Location = new System.Drawing.Point(208, 191);
            label12.Name = "label12";
            label12.Size = new System.Drawing.Size(12, 15);
            label12.TabIndex = 17;
            label12.Text = "-";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.BackColor = System.Drawing.Color.White;
            label13.Location = new System.Drawing.Point(299, 191);
            label13.Name = "label13";
            label13.Size = new System.Drawing.Size(12, 15);
            label13.TabIndex = 18;
            label13.Text = "-";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.BackColor = System.Drawing.Color.White;
            label14.Location = new System.Drawing.Point(299, 231);
            label14.Name = "label14";
            label14.Size = new System.Drawing.Size(12, 15);
            label14.TabIndex = 21;
            label14.Text = "-";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.BackColor = System.Drawing.Color.White;
            label15.Location = new System.Drawing.Point(208, 231);
            label15.Name = "label15";
            label15.Size = new System.Drawing.Size(12, 15);
            label15.TabIndex = 20;
            label15.Text = "-";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.BackColor = System.Drawing.Color.White;
            label16.Location = new System.Drawing.Point(11, 231);
            label16.Name = "label16";
            label16.Size = new System.Drawing.Size(12, 15);
            label16.TabIndex = 19;
            label16.Text = "-";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.BackColor = System.Drawing.Color.White;
            label17.Location = new System.Drawing.Point(299, 274);
            label17.Name = "label17";
            label17.Size = new System.Drawing.Size(12, 15);
            label17.TabIndex = 24;
            label17.Text = "-";
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.BackColor = System.Drawing.Color.White;
            label18.Location = new System.Drawing.Point(208, 274);
            label18.Name = "label18";
            label18.Size = new System.Drawing.Size(12, 15);
            label18.TabIndex = 23;
            label18.Text = "-";
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.BackColor = System.Drawing.Color.White;
            label19.Location = new System.Drawing.Point(11, 274);
            label19.Name = "label19";
            label19.Size = new System.Drawing.Size(12, 15);
            label19.TabIndex = 22;
            label19.Text = "-";
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.BackColor = System.Drawing.Color.White;
            label20.Location = new System.Drawing.Point(299, 320);
            label20.Name = "label20";
            label20.Size = new System.Drawing.Size(12, 15);
            label20.TabIndex = 27;
            label20.Text = "-";
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.BackColor = System.Drawing.Color.White;
            label21.Location = new System.Drawing.Point(208, 320);
            label21.Name = "label21";
            label21.Size = new System.Drawing.Size(12, 15);
            label21.TabIndex = 26;
            label21.Text = "-";
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.BackColor = System.Drawing.Color.White;
            label22.Location = new System.Drawing.Point(11, 320);
            label22.Name = "label22";
            label22.Size = new System.Drawing.Size(12, 15);
            label22.TabIndex = 25;
            label22.Text = "-";
            // 
            // label23
            // 
            label23.AutoSize = true;
            label23.BackColor = System.Drawing.Color.White;
            label23.Location = new System.Drawing.Point(299, 364);
            label23.Name = "label23";
            label23.Size = new System.Drawing.Size(12, 15);
            label23.TabIndex = 30;
            label23.Text = "-";
            // 
            // label24
            // 
            label24.AutoSize = true;
            label24.BackColor = System.Drawing.Color.White;
            label24.Location = new System.Drawing.Point(208, 364);
            label24.Name = "label24";
            label24.Size = new System.Drawing.Size(12, 15);
            label24.TabIndex = 29;
            label24.Text = "-";
            // 
            // label25
            // 
            label25.AutoSize = true;
            label25.BackColor = System.Drawing.Color.White;
            label25.Location = new System.Drawing.Point(11, 364);
            label25.Name = "label25";
            label25.Size = new System.Drawing.Size(12, 15);
            label25.TabIndex = 28;
            label25.Text = "-";
            // 
            // Form2
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            BackColor = System.Drawing.SystemColors.ActiveBorder;
            ClientSize = new System.Drawing.Size(374, 487);
            Controls.Add(label23);
            Controls.Add(label24);
            Controls.Add(label25);
            Controls.Add(label20);
            Controls.Add(label21);
            Controls.Add(label22);
            Controls.Add(label17);
            Controls.Add(label18);
            Controls.Add(label19);
            Controls.Add(label14);
            Controls.Add(label15);
            Controls.Add(label16);
            Controls.Add(label13);
            Controls.Add(label12);
            Controls.Add(label11);
            Controls.Add(label10);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(pictureBox1);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(button1);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(richTextBox1);
            Name = "Form2";
            Text = "Form2";
            Load += Form2_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
    }
}