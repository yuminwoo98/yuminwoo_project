﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pj01
{
    public partial class Form1 : Form
    {

        private int Lan = 0;
        private int m1count = 0;

        StringBuilder sb1 = new StringBuilder();

        //1번 와플 갯수
        private int menu1num = 0;
        private int menu2num = 0;

        public int SumPrive = 0;

        public int OrderNum = 0;
        public int ssprice;
        public int ooderNum;

        //1번와플 price
        private int menu1 = 3500;
        private int menu2 = 4500;

        public int OnlyM1 = 0;
        public int OnlyM2 = 0;

        public Form1()
        {
            InitializeComponent();
            listView1.View = View.Details;     //   <<리스트뷰의 컬럼 나오게 하는 행
            listView1.Items.Clear();

            // string[,] menuarr = new string[,2];
        }
        List<string> waffle1 = new List<string>();
        List<string> waffle2 = new List<string>();


        public void AddMenu(string name, int num, int price)
        {
            for (int i = 0; i < listView1.SelectedItems.Count; i++)
            {
                if (listView1.SelectedItems[i].Text == name)
                {
                    listView1.SelectedItems[i].SubItems[1].Text = num.ToString();
                    listView1.SelectedItems[i].SubItems[2].Text = (price * num).ToString();

                }
            }
        }
        private void button1_Click(object sender, EventArgs e) //언어
        {
            Lan++;

            if ((Lan % 2) == 0)
            {
                // Tmenu1.Text = "영어";
            }
            else
            {
                // Tmenu1.Text = "한글";
            }
        }

        private void splitContainer1_SplitterMoved(object sender, SplitterEventArgs e)
        {

        }

        private void splitContainer1_Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void tabPage6_Click(object sender, EventArgs e)
        {
            tabPage6.BackColor = Color.BlueViolet;
        }

        private void tabPage4_Click(object sender, EventArgs e)
        {

        }

        private void splitContainer2_Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {

        }

        private void splitContainer2_Panel2_Paint(object sender, PaintEventArgs e)
        {

        }




        private void btn_test_Click(object sender, EventArgs e)
        {
            menu1num++;
            //listView1.Clear();

            if (menu1num == 1)
            {

                listView1.Items.Add(new ListViewItem(new string[] { btn_test.Text, menu1num.ToString(), (menu1num * menu1).ToString() }));
            }
            else
                AddMenu(btn_test.Text, menu1num, menu1);

            SumPrive += int.Parse(label1.Text);

            textBox2.Text = SumPrive.ToString();
            OrderNum++;

            textBox3.Text = OrderNum.ToString();




            OnlyM1 += int.Parse(label1.Text);


        }

        private void btn_test2_Click(object sender, EventArgs e)
        {
            menu2num++;

            if (menu2num == 1)
            {

                listView1.Items.Add(new ListViewItem(new string[] { btn_test2.Text, menu2num.ToString(), (menu2num * menu2).ToString() }));
            }
            else
                AddMenu(btn_test2.Text, menu2num, menu2);
            SumPrive += int.Parse(label2.Text);
            textBox2.Text = SumPrive.ToString();

            OrderNum++;

            textBox3.Text = OrderNum.ToString();

        }

        private void button7_Click_1(object sender, EventArgs e)
        {
            //  listView1.SelectedItems[0]
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button8_Click(object sender, EventArgs e)
        {
            MessageBox.Show("현재 선택 불가능한 상품입니다. \n 다른 메뉴를 선택해 주세요.");
        }

        private void button9_Click(object sender, EventArgs e)
        {
            MessageBox.Show("현재 선택 불가능한 상품입니다. \n 다른 메뉴를 선택해 주세요.");
        }

        private void button10_Click(object sender, EventArgs e)
        {
            MessageBox.Show("현재 선택 불가능한 상품입니다. \n 다른 메뉴를 선택해 주세요.");
        }

        private void button11_Click(object sender, EventArgs e)
        {
            MessageBox.Show("현재 선택 불가능한 상품입니다. \n 다른 메뉴를 선택해 주세요.");
        }

        private void button12_Click(object sender, EventArgs e)
        {
            MessageBox.Show("현재 선택 불가능한 상품입니다. \n 다른 메뉴를 선택해 주세요.");
        }

        private void button13_Click(object sender, EventArgs e)
        {
            MessageBox.Show("현재 선택 불가능한 상품입니다. \n 다른 메뉴를 선택해 주세요.");
        }

        private void button17_Click(object sender, EventArgs e)
        {
            MessageBox.Show("현재 선택 불가능한 상품입니다. \n 다른 메뉴를 선택해 주세요.");
        }

        private void button16_Click(object sender, EventArgs e)
        {
            MessageBox.Show("현재 선택 불가능한 상품입니다. \n 다른 메뉴를 선택해 주세요.");
        }

        private void button15_Click(object sender, EventArgs e)
        {
            MessageBox.Show("현재 선택 불가능한 상품입니다. \n 다른 메뉴를 선택해 주세요.");
        }

        private void button14_Click(object sender, EventArgs e)
        {
            MessageBox.Show("현재 선택 불가능한 상품입니다. \n 다른 메뉴를 선택해 주세요.");
        }

        private void button21_Click(object sender, EventArgs e)
        {
            MessageBox.Show("현재 선택 불가능한 상품입니다. \n 다른 메뉴를 선택해 주세요.");
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("현재 카카오페이 결제는 불가능 합니다.\n다른 결제 방법을 선택하여 주십시오.");
        }




        public void btn_pay_Click(object sender, EventArgs e)
        {
            string b = SumPrive.ToString();
            string a = OrderNum.ToString();
            Form2 form2 = new Form2(a, b);
            form2.ShowDialog();
            //
            //
            //

            waffle1.Add(btn_test.Text);
            waffle1.Add(menu1num.ToString());
            waffle1.Add(OnlyM1.ToString());

            foreach (var i in waffle1)
            {
                sb1.Append(string.Format("{0}     ", i));
            }
            //waffle1.Add();
            string qqq = sb1.ToString();
            Form2 form2_0 = new Form2(qqq);
            //   button1.Text = qqq;




            waffle2.Add(btn_test2.Text);
            waffle2.Add(menu2num.ToString());

        }

    }
}
